/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

/**
 * A class for the Frozen Goods items.
 * This is one of the sub-classes that holds the names and prices of the items under the Frozen Goods category.
 * It overrides the String[] getName() and double[] getPrice() methods.
 * With this, it rewrites the data within these methods for ones called, these will be the ones that are retrieved.
 * @author TechyPH
 */
public class Frozen extends Goods {
 // @override
	public String[] getName() {
		String[] name = {"Chorizo", "Hot Dog", "Tocino"};
		return name;
	}

 // @override
	public double[] getPrice() {
		double[] price = {25.00, 20.50, 23.50};
		return price;
	}
}
