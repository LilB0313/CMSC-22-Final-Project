/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

import java.io.*;
import java.util.Scanner;

/**
 * Responsible for all record related handling. 
 * @author TechyPH
 */
public class FileManager {
	private static Scanner input = new Scanner(System.in);
	private static GetGoods goods = new GetGoods();
	
	/**
	 * This is called from Main.
	 * Here, we begin by writing the orders the customers have chosen.
	 * If wished, it appends additional orders to the file.
	 * 
	 * @param cust_name From Main, cust_name is passed to FileManager. Used as the filename of our file record.
	 * @param date From Main, date is passed to FileManager. Written on the record to indicate the date of purchase. 
	 * @param times From Main, times is passed to FileManager. Counts the number of times the users had ordered.
	 * @return cost Returns the total cost for each purchase.
	 */	
	public double WriteOrder (String cust_name, String date, int times) {
		int picknum, option, quantity;
		double cost = 0;
		
		File order = new File("C:\\Users\\TechyPH\\Desktop\\Customer's Orders\\", cust_name);
	     
		try (FileWriter Writeorder = new FileWriter(order, true); BufferedWriter bw = new BufferedWriter(Writeorder); PrintWriter pw = new PrintWriter(bw);) {
    		pw.printf("\n%30s %dth %s\n", "~", times, " Order ~");
    		pw.printf("\n%30s\n", date);
            Present menu = new Present();
            option = menu.WhatMenu();
            quantity = menu.SubMenu(option);
            
            for (int i = 1; i <= quantity; i++) {
            	Goods glist = goods.getGoods(option);
            	String[] goods_list = glist.getName();
        		double[] price_list = glist.getPrice();

            	do {
            		System.out.printf("\nEnter order number %d: ", i);
            		picknum = input.nextInt();

            		if (picknum < 1 || picknum > 4) {
            			System.out.println("\nDear Customer, Input number is insufficient. Please, try again.\n\n");
            		}
            	} while(picknum < 1 || picknum > 4);

            	cost += price_list[picknum - 1];

            	pw.printf("\n%25s \t\t%5s %.2f\n", goods_list[picknum - 1], "P", price_list[picknum - 1]);
            }
            
         } catch (IOException io) {
        	 io.printStackTrace();
         }
		
		return cost;
	}
	
	
	/**
	 * This is called out from Main.
	 * Aids in reading the records after it is written.
	 * 
	 * @param cust_name From Main, cust_name is passed to FileManager. Used to narrow down and identify what file we are looking for.
	 * @throws FileNotFoundException If there is a problem encountered when we try to read the file. 
	 */
	public static void ReadOrder(String cust_name) throws FileNotFoundException {
    	File order = new File("C:\\Users\\TechyPH\\Desktop\\Customer's Orders\\", cust_name);
    	
    	try {
    		Scanner scanfile = new Scanner(order);

        	while (scanfile.hasNext()) {
        		String text = scanfile.nextLine();
        		System.out.println(text);
        	}
    	} catch (IOException io){}
    }
	
	
	/**
	 * Appends the total cost of the purchase into our records
	 * @param cust_name Helps in navigating which file we will be appending the total cost.
	 * @param cost Holds the cost of purchase.
	 * @throws FileNotFoundException If the file is not found and we will fail to run it.
	 */
	public static void WriteCost(String cust_name, double cost) throws FileNotFoundException {
		File order = new File("C:\\Users\\TechyPH\\Desktop\\Customer's Orders\\", cust_name);
		
		try (FileWriter Writeorder = new FileWriter(order, true); BufferedWriter bw = new BufferedWriter(Writeorder); PrintWriter pw = new PrintWriter(bw);) {
			pw.printf("\n\n%25s \t\t%5s %.2f\n\n", "Total: ", "P", cost);
		} catch (IOException io){}
	}
}
