/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

import java.util.*;

/**
 * Here is where the transaction happens.
 * Checks for sufficient cash entries.
 * Returns the change.
 */
public class Payment {
	private Scanner input = new Scanner(System.in);

	/**
	 * Ask for the cash from the user and computes for the change.
	 * It also shows a warning, when insufficient cash entry is detected.
	 * @param cost Gets the total cost for each transaction. Used for computing the change.
	 * @return Returns the change for each purchase.
	 */
	public double Transaction(double cost) {
		double cash = 0, change = 0;

		do {
			System.out.print("\nEnter your payment amount: P ");
			cash = input.nextDouble();

			if (cash < cost)
		    {
		      System.out.printf("\nSorry, insufficient cash entry. Please try again.\n");
		    }
		} while (cash < cost);

		change = cash - cost;

		return change;
	}
}
