/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

/**
 * This class is a part of our Creative Design Pattern.
 * When this class is called, it decides which sub-class we will be visiting.
 * @author TechyPH
 */
public class GetGoods {
	
	/**
	 * When this is called, it is used to access Goods.java.
	 * Allows us to use the other sub-classes of the Factory Design Pattern.
	 * @param choice Used to narrow which sub-class we will be visiting to retrieve the data from.
	 * @return The appropriate sub-class that we will be creating.
	 */
    public Goods getGoods(int choice) {
        if(choice == 1) {
            return new Fruits();
        } else if(choice == 2) {
            return new Frozen();
        } else if(choice == 3) {
            return new Eggs();
        } else if(choice == 4) {
            return new Desserts();
        } else {
            return null;
        }
   }
}
