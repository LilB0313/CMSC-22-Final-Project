/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

import java.util.*;
import java.io.*;

/** 
 * Is the main class of our program, hence, the name.
 * Where all the program is compiled.
*/
public class Main {
	private static Scanner input = new Scanner(System.in);
	private static BufferedReader readlines = new BufferedReader(new InputStreamReader(System.in));
	private static FileManager file = new FileManager();
	private static double cost;
	private static String cust_name, date;
	private static int stop, times = 1;

	/**
	 * The very first greeting that shows in the console.
	 * Executes for the nth times.
	 * Depends on the number of times the users wants to add an order or run the code.
	 * 
	 * @param args There is no parameters in Main
	 * @throws Exception If BufferedReader fails to read the input 
	 */
    public static void main(String[] args) throws Exception {
    	System.out.println("\n                    Welcome, Customer!          \n ");
        System.out.println("        You are shopping at Nanay's Goods & All ...          \n ");
        System.out.println("              _____________________________				\n\n ");
        System.out.print("Enter Customer's name: ");
        cust_name = readlines.readLine();
        System.out.print("\nEnter date of order [ex. mm/dd/yyyy]: ");
        date =  readlines.readLine();
    	
        do {
        	start_ordering();
            
        	FileManager.WriteCost(cust_name, cost);
        	cost = 0;
        	
            System.out.println("\n\nDear Customer,");
            System.out.println("\n\t Do you wish to stop shopping?\n");
            System.out.println("\nSelect the number of your action:\n");
            System.out.println("\tPress Any to Leave\n");
            System.out.println("\tPress 1 to Stay\n");
            System.out.print("\nEnter your action: ");
            stop = input.nextInt();
        } while (stop == 1);
        
        times = 0;

        System.out.println("\nDear  Customer, \n\tThank you for your patronage! Until next time!\n");
    }

    /**
     * Here is where the ordering happens.
     * Executes for the nth times until the customers wishes to stop.
     * Calls out to FileManager to write, append and read the file containing the details of each order.
     *  
     * @throws Exception If BufferedReader fails to read the input 
     */
    public static void start_ordering() throws Exception {
        do {
        	cost += file.WriteOrder(cust_name, date, times);
        	
        	System.out.printf("\n\t* %s's Current Order *\n", cust_name);
            FileManager.ReadOrder(cust_name);

            System.out.printf("\nCurrent Bill: P %.2f", cost);

            System.out.println("\n\nDo you want to continue ordering?\n");
            System.out.println("\nSelect the number of your action:\n");
            System.out.println("\tPress Any to Stop\n");
            System.out.println("\tPress 1 to Continue\n");
            System.out.print("\nEnter your action: ");
            stop = input.nextInt(); 
            times ++;
        } while (stop == 1);

        System.out.printf("\n\t* %s's Final Order *\n", cust_name);
        FileManager.ReadOrder(cust_name);

        System.out.printf("\n\nFinal Bill: P %.2f", cost);
        
        Payment pay = new Payment();
        double change = pay.Transaction(cost);

        System.out.printf("\nChange: P %.2f\n", change);
    }
}
