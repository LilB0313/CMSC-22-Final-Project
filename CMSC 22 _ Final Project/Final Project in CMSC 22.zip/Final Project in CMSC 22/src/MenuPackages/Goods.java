/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

/**
 * Creative Design Pattern: Factory Design Pattern
 * An abstract class which allows us to use other classes with the same methods.
 * This methods are String[] getName() and double[] getPrice.
 * @author TechyPH
 */
abstract class Goods{
	protected String[] name;
	protected double[] price;
	abstract String[] getName();
	abstract double[] getPrice();
}