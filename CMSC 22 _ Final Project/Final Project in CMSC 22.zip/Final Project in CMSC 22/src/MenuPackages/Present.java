/**
 * The MenuPackages is a self-made java package that contains the necessary 
 * classes and interfaces for the ordering program to fully function.
 */
package MenuPackages;

import java.util.*;

/**
 * Does all the presentation of the menus.
 * Decides what main and Sub-Menus it will display.
 * Furthermore, it depends on the inputs of the users. 
 */
public class Present {
	private Scanner input = new Scanner(System.in);
	private String[] main_menu = {"Fruits", "Frozen Goods", "Eggs", "Desserts"};
	private GetGoods goods = new GetGoods();
    private int quantity, option;

    /** 
     * Here, it displays the menu for which the users may want to purchase.
     * Displays the Fruits, Frozen Goods, Eggs, and Desserts Menus.
     * Furthermore, returns what menu the customer has chosen. 
     * @return What option or the menu the users have chosen is returns when this method is called.
     */
	public int WhatMenu() {
    	do {
			System.out.println("\n        ~ Please select the menu of your choice ~");

			for (int i = 0; i < 4; i++) {
				System.out.printf("\n%20d. %s\n", i + 1, main_menu[i]);
			}

			System.out.printf("\n\tEnter the number of chosen menu : ");
			option = input.nextInt();

			if (option < 1 || option > 4) {
				System.out.print("\nDear Customer, insufficient entry. Please, try again.\n");
		    }
		} while (option < 1 || option > 4);
    	return option;
    }

	/**
	 * Here, it displays the sub-menu the users may want to purchase.
	 * It depends on what main menu the users have chosen.
	 * It displays each items name and prices.
	 * Also, it heavily relays on GetGoods.java for the data to be displayed.
	 * Returns the quantity of items the customer wishes to order
	 * @param option Relays on option to narrow down what sub-menu to be displayed.
	 * @return The number of items the users wish to order.
	 */
	public int SubMenu(int option) {
		do {
			System.out.printf("\n\n%25s %s *\n", "*", main_menu[option - 1]);

			for (int j = 0; j < 3; j++) {
	            Goods glist = goods.getGoods(option);
	            String[] goods_list = glist.getName();
	    		double[] price_list = glist.getPrice();

	            System.out.printf("\n%20d. %s \t\t%5s %.2f\n", j + 1, goods_list[j], "P", price_list[j]);
			}
			Display();
			
		} while (quantity < 1);
		return quantity;
	}

	/**
	 * For getting the quantity of items.
	 * Warns the users for insufficient entry of items.
	 * For instance, is the input is less than 1, then this is out of bound.
	 */
	protected void Display() {
		System.out.print("\n\tEnter desired number of item(s): ");
        quantity = input.nextInt();

        if (quantity < 1) {
        	System.out.print("\nDear Customer, number of items is insufficient. Please, try again.\n");
        }
	}
}
